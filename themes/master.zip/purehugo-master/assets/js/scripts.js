$(function(){
    $('.prettySocial').prettySocial();
});